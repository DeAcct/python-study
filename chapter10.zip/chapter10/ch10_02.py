def greet():       # 함수 정의
     print('Hello.')
     print('Nice to meet you.')

greet()            # 함수 호출

# 위내용 실행 후 함수 호출로 부천대학교, 과명 출력하는 함수 정의 호출하기 
