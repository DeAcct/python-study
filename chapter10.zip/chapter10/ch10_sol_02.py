# 함수 선언, 이하 코드 작성

    print(lengthCm, 'cm = ', lengthCm * 0.393701, 'inch')

lengthCm = float(input('길이를 입력하세요.(cm) '))
 # 함수 호출, # 이하 코드 작성
