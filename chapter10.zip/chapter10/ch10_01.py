userName = 'Hong gil dong'

print('이름 : ', userName)
# 이하 코드 작성, 내장 함수 
