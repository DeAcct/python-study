def sa_Temp():
    print('온도센서 작동을 시작한다.')

 st_Temp():
    print('온도센서 작동을 중지한다.')

# 이하 코드 작성
