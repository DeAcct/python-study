def getMemberInDatabase():
# 이하 코드 작성

def sendMemberIdByEmail():
# 이하 코드 작성

m_name = input('이름을 입력하세요. ')
m_mail = input('메일 주소를 입력하세요. ')

getMemberInDatabase()
sendMemberIdByEmail()

# 교재 335페이지 확인문제 1 작업
