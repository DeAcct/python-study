def greet():       # 함수 정의
     print('Hello.')
     print('Nice to meet you.')

greet()            # 첫 번째 함수 호출
greet()            # 두 번째 함수 호출
greet()            # 세 번째 함수 호출
