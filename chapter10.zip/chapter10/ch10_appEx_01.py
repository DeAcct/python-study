def introKor():
    print('')

def introEng():
    print('')

def introJap():
    print('こんにちは.')

selectNum = int(input('where are you from? 1.한국, 2.USA, 3.Japan '))
# 이하 코드 작성

