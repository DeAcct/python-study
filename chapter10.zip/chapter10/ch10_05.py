def fun1():
    print('fun1 함수를 호출합니다!')

def fun2():
    print('fun2 함수를 호출합니다!')

def fun3():
    # 이하 코드 작성

    
    print('fun3 함수를 호출합니다!')

# 이하 코드 작성

# 교재 337페이지 확인문제 이하 코드 작성 함수명은 각자 설정 
