# 함수 선언, 이하 코드 작성

    print('이동 거리는', hourData * speedData, 'km 입니다.')

hourData = (input('이동 시간을 입력하세요. '))
speedData = (input('이동 속도를 입력하세요. '))
# 함수 호출,이하 코드 작성
