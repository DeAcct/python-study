fruits = ('apple', 'banana', 'plum', 'watermelon', 'peach')
#이하 코드 작성 

