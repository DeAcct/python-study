colors = ('Red', 'Orange', 'Yellow', 'Green', 'Blue', 'Indigo', 'Purple')
cs =   

"""cs.sort(r)  
print(cs)

(reverse = False)   
print(cs)"""
