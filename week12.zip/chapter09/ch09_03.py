colors = ('Red', 'Orange', 'Yellow', 'Green', 'Blue', 'Indigo', 'Purple')
print('colors의 자료형 :', type(colors))

colors = (colors)                
print('colors의 자료형 :', type(colors))

colors = (colors)                
print('colors의 자료형 :', type(colors))
