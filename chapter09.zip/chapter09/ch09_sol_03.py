scores = ('A', 'A+', 'B', 'B-', 'F', 'A++')

if 'F' in scores:
    print('경고')
# A+ 출력 코드 추가 작성  

