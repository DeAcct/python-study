import turtle
t= turtle.Turtle()
t.shape('turtle')

# x, y좌표 및 회전각도 데이터 :  좌표값 다르게 지정 8각형 추가 , 확인문제 참고 하여 색상도 지정하여 작업 
datas = 

for points in datas:
    t.up()
    t.goto(points[0], points[1])      # x, y좌표 설정
    t.down()

    for num in range(2, len(points)): # 회전하면서 그리기
        t.forward(50)
        t.left(points[num])

        
