import turtle
t= turtle.Turtle()
t.shape('turtle')

# x, y좌표 및 회전각도 데이터

