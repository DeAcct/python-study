colors = ('Red', 'Orange', 'Yellow', 'Green', 'Blue', 'Indigo', 'Purple')
print(colors)
print('colors의 자료형 :', type(colors))

cs =   
print(cs)
print('cs의 자료형 :', type(cs))
